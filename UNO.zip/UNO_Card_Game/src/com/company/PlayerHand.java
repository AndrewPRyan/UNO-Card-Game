package com.company;

/**
 * Created by andrewryan on 3/5/16.
 */
public class PlayerHand extends CardDeck {

    PlayerHand() {

        super();

    }

    PlayerHand(int capacity) {

        super(capacity);

    }

}
